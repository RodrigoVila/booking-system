import { Request, Response } from "express";

import { EmployeeSchema, EmployeeType } from "shared-types";

import { Employee } from "../models/employee";

type NullableEmployeeType = EmployeeType | null;

const getEmployees = async (_: Request, res: Response) => {
  console.log("HIII");
  try {
    const employees: EmployeeType[] = await Employee.find();
    res.status(200).json({ success: true, data: employees });
  } catch (err) {
    res.status(500).json({ success: false, message: (err as Error).message });
  }
};

const getEmployeeById = async (req: Request, res: Response) => {
  try {
    const employee: NullableEmployeeType = await Employee.findById(
      req.params.id
    );
    if (employee) {
      res.status(200).json({ success: true, data: employee });
    } else {
      res.status(404).json({ success: false, message: "Employee not found" });
    }
  } catch (err) {
    res.status(500).json({ success: false, message: (err as Error).message });
  }
};

const createEmployee = async (req: Request, res: Response) => {
  try {
    const parsedData = EmployeeSchema.parse(req.body);
    const employee = new Employee(parsedData);
    const newEmployee: EmployeeType = await employee.save();

    res.status(201).json({ success: true, data: newEmployee });
  } catch (err) {
    res.status(400).json({ success: false, message: (err as Error).message });
  }
};

const updateEmployee = async (req: Request, res: Response) => {
  try {
    const updatedEmployee: NullableEmployeeType =
      await Employee.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
      });
    if (updatedEmployee) {
      res.status(200).json({ success: true, data: updatedEmployee });
    } else {
      res.status(404).json({ success: false, message: "Employee not found" });
    }
  } catch (err) {
    res.status(500).json({ success: false, message: (err as Error).message });
  }
};

const deleteEmployee = async (req: Request, res: Response) => {
  try {
    const deletedEmployee: NullableEmployeeType =
      await Employee.findByIdAndDelete(req.params.id);
    if (deletedEmployee) {
      res.status(200).json({ success: true, data: deletedEmployee });
    } else {
      res.status(404).json({ message: "Employee not found" });
    }
  } catch (err) {
    res.status(500).json({ message: (err as Error).message });
  }
};

export {
  getEmployees,
  getEmployeeById,
  createEmployee,
  updateEmployee,
  deleteEmployee,
};
