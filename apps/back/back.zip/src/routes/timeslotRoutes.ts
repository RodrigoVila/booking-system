import express from "express";
import {
  getTimeslots,
  getTimeslotById,
  createTimeslot,
  updateTimeslot,
  deleteTimeslot,
} from "../controllers/timeslotController";

const router = express.Router();

router.route("/api/timeslots").get(getTimeslots).post(createTimeslot);

router
  .route("/api/timeslots/:id")
  .get(getTimeslotById)
  .put(updateTimeslot)
  .delete(deleteTimeslot);

export { router };
