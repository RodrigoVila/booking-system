import express from "express";
import {
  getServices,
  getServiceById,
  createService,
  updateService,
  deleteService,
} from "../controllers/serviceController";

const router = express.Router();

router.route("/api/services").get(getServices).post(createService);

router
  .route("/api/services/:id")
  .get(getServiceById)
  .put(updateService)
  .delete(deleteService);

export { router };
