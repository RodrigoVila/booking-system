import express from "express";
import {
  getUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
} from "../controllers/userController";

const router = express.Router();

router.route("/api/users").get(getUsers).post(createUser);

router
  .route("/api/users/:id")
  .get(getUserById)
  .put(updateUser)
  .delete(deleteUser);

export { router };
